library(testthat)
library(RBaseX)

test_check("RBaseX")
